# Modification Notice

This copy was modified by Parmanand Jha.

Original project: SURVIVOR by Scott Schiller.
The original project license and attribution files are retained.

Changes in this copy are limited to author/creator display metadata and the removal of the original development-date wording from non-license comments.
